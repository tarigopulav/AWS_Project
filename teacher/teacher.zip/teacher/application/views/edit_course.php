<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/images/favicon.png">
    <title>Edit Course </title>
   <?php include('parts/head.php'); ?>
</head>

<body class="skin-default fixed-layout">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="loader">
            <div class="loader__figure"></div>
            <p class="loader__label">Elite admin</p>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <?php include('parts/header.php');?>
       <?php include('parts/left_sidebar.php');?>



        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">Edit Course</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                                <li class="breadcrumb-item active">Edit Course</li>
                            </ol>
                        </div>
                    </div>
                </div>
               
                <?php if($this->session->flashdata('success')){?>
                <div class="alert alert-success alert-rounded"> <i class="ti-user"></i>  <?php echo $this->session->set_flashdata('success');?>
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                                        </div>
                <?php } ?>
               

                <?php if($this->session->flashdata('error')){?>
                <div class="alert alert-danger alert-rounded"> <i class="ti-user"></i> <?php echo $this->session->set_flashdata('error');?>
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                                        </div>
                <?php } ?>
               



                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header bg-info">
                                <h4 class="m-b-0 text-white">Edit Course</h4>
                            </div><?php foreach ($edit_data as $edit_data) {?>
                    <form method="POST" action="<?php echo base_url();?>user/update_add_course/<?php echo $edit_data['id']?>" enctype='multipart/form-data'>
                        <div class="card-body">

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                           
                              <div class="row">
                                  <div class="col-md-12">
                                     <h5 class="m-t-30 m-b-10">Course Name<span style="color:red">*</span></h5>
                                     <input type="text" name="course" data-style="form-control" class="form-control" value="<?php echo $edit_data['course_name']?>" required="">
                                  </div>
                                </div>
                                <br>
                                <div>
                                    <div class="form-actions">
                                      <button type="submit" class="btn btn-success" name="submit"> <i class="fa fa-check"></i> Save</button>
                                      <button type="button" class="btn btn-inverse">Cancel</button>
                                    </div>
                                </form>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Row -->
         <?php include('parts/footer.php');?>
 
</body>
</html>