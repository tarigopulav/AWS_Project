<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/images/favicon.png">
    <title>Elite Admin Template - The Ultimate Multipurpose admin template</title>
    <!-- Custom CSS -->
    <link href="<?php echo base_url();?>assets/dist/css/style.min.css" rel="stylesheet">
    <!--map-->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/styles.css">

</head>

<body class="skin-default fixed-layout">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="loader">
            <div class="loader__figure"></div>
            <p class="loader__label">Elite admin</p>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <!-- ============================================================== -->
      <?php include('header.php');?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">Area Properties</h4>
                    </div>
                    <!--<div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                                <li class="breadcrumb-item active">View Jobs</li>
                            </ol>
                            <button type="button" class="btn btn-info d-none d-lg-block m-l-15"><i class="fa fa-plus-circle"></i> 
                             <a href="<?php echo base_url();?>user/create_job" style="color:white;">Create New Job</a></button>
                        </div>
                    </div>-->
                </div>
                <!-- ============================================================== -->

           
                <!-- row -->
                  <!--<form method="POST" action="<?php //echo base_url();?>user/table"> -->                   
                <div class="row">                    
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <!--map-->
        <body onload="initialize()">  
  <div id="map-canvas"></div>
  <div class="lngLat"><span class="one">Lat</span><span class="two">,Lng</span></div>
</body>
<!--<button id="clipboard-btn" onclick="copyToClipboard(document.getElementById('info').innerHTML)">Copy to Clipboard</button>--><script>
var yourGlobalVariable;
function getPolygonCoords(htmlStr) {

}
</script>
<form action="<?php echo base_url();?>user/map_data" method="post" id="fm">
  <textarea id="info" name="mapdata" ></textarea>

</form>


                                <!--map End-->                                
                                <h4 class="card-title"></h4>
                                <div class="table-responsive">
                                    <div>
                                        <label for="usr">Plot:</label>
                                        <input type="text" class="form-control" data-style="form-control" name="plot">
                                        </div>
                                        <div>
                                             <label for="usr">Area Type:</label>
                                        <select name="area" class="form-control">
                                            <option value="Vegetation">Vegetation</option>
                                            <option value="Proposed_Building">Proposed Building</option>
                                        </select>
                                        </div>
                                        <div style="margin-top: 12px;">
                                        <button type="button" class="btn btn-default" data-toggle="collapse" data-target="#demo" style="width: 500px;text-align: left;">Post Info</button>
                                        <div id="demo" class="collapse">
                                            <div class="row">
                                           <div class="col-md-6">
                                              <label for="usr">Class:</label>
                                            <select name="class" class="form-control">
                                            <option value="forest">Class A Forest</option>
                                            <option value="2">2</option>
                                            
                                        </select>
                                           </div>
                                           <div class="col-md-6">
                                              <label for="usr">Description Type:</label>
                                             <select name="desc" class="form-control">
                                            <option value="forest">Forest</option>
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                            <option value="4">4</option>
                                        </select>
                                           </div>
                                           </div>
                                     <div class="form-group">
                                    <label for="comment"></label>
                                    <textarea class="form-control" name="msg" rows="5" id="demo"></textarea>
                                  </div>
                                   <div class="checkbox">
                                  <label>Open Shrubland <input type="checkbox" value="shrubland" name="shrubland"></label>
                                </div>
                                <div class="checkbox">
                                  <label>Open Woodland <input type="checkbox" value="woodland" name="woodland"></label>
                                </div>
                                        <div style="width: 20%;">
                                            <label for="slop">Slop Direction : </label>
                                           <select name="direction" class="form-control">
                                            <option value="0">Upslope/0° 0</option>
                                            <option value="1">Downslope/1°</option>
                                            <option value="2">Downslope/2°</option>
                                            <option value="3">Downslope/3°</option>
                                            <option value="4">Downslope/4°</option>
                                            <option value="5">Downslope/5°</option>
                                            <option value="6">Downslope/6°</option>
                                            <option value="7">Downslope/7°</option>
                                            <option value="8">Downslope/8°</option>
                                            <option value="9">Downslope/9°</option>
                                            <option value="10">Downslope/10°</option>
                                            <option value="11">Downslope/11°</option>
                                            <option value="12">Downslope/12°</option>
                                            <option value="13">Downslope/13°</option>
                                            <option value="14">Downslope/14°</option>
                                            <option value="15">Downslope/15°</option>
                                            <option value="16">Downslope/16°</option>
                                            <option value="17">Downslope/17°</option>
                                            <option value="18">Downslope/18°</option>
                                            <option value="19">Downslope/19°</option>
                                            <option value="20">Downslope/20°</option>
                                        </select>
                                        </div>
                                        <div>
                                            <label for="usr">Photo: </label>
                                            <a href="#">Select Photo </a>
                                        </div>
                                        </div>
                                      </div>
                                      <div>
                                    <button onclick="myFunction()" type="submit" class="btn btn-default" style="float: right;">submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                 </form>
                <!-- row -->
                
                <!-- row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <div class="right-sidebar">
                    <div class="slimscrollright">
                        <div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
                        <div class="r-panel-body">
                            <ul id="themecolors" class="m-t-20">
                                <li><b>With Light sidebar</b></li>
                                <li><a href="javascript:void(0)" data-skin="skin-default" class="default-theme working">1</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-green" class="green-theme">2</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-red" class="red-theme">3</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-blue" class="blue-theme">4</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-purple" class="purple-theme">5</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-megna" class="megna-theme">6</a></li>
                                <li class="d-block m-t-30"><b>With Dark sidebar</b></li>
                                <li><a href="javascript:void(0)" data-skin="skin-default-dark" class="default-dark-theme ">7</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-green-dark" class="green-dark-theme">8</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-red-dark" class="red-dark-theme">9</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-blue-dark" class="blue-dark-theme">10</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-purple-dark" class="purple-dark-theme">11</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-megna-dark" class="megna-dark-theme ">12</a></li>
                            </ul>
                            <ul class="m-t-20 chatonline">
                                <li><b>Chat option</b></li>
                                <li>
                                    <a href="javascript:void(0)"><img src="../assets/images/users/1.jpg" alt="user-img" class="img-circle"> <span>Varun Dhavan <small class="text-success">online</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="../assets/images/users/2.jpg" alt="user-img" class="img-circle"> <span>Genelia Deshmukh <small class="text-warning">Away</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="../assets/images/users/3.jpg" alt="user-img" class="img-circle"> <span>Ritesh Deshmukh <small class="text-danger">Busy</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="../assets/images/users/4.jpg" alt="user-img" class="img-circle"> <span>Arijit Sinh <small class="text-muted">Offline</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="../assets/images/users/5.jpg" alt="user-img" class="img-circle"> <span>Govinda Star <small class="text-success">online</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="../assets/images/users/6.jpg" alt="user-img" class="img-circle"> <span>John Abraham<small class="text-success">online</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="../assets/images/users/7.jpg" alt="user-img" class="img-circle"> <span>Hritik Roshan<small class="text-success">online</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="../assets/images/users/8.jpg" alt="user-img" class="img-circle"> <span>Pwandeep rajan <small class="text-success">online</small></span></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
        <?php include('footer.php');?>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="<?php echo base_url();?>assets/node_modules/jquery/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?php echo base_url();?>assets/node_modules/popper/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="<?php echo base_url();?>assets/dist/js/perfect-scrollbar.jquery.min.js"></script>
    <!--Wave Effects -->
    <script src="<?php echo base_url();?>assets/dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="<?php echo base_url();?>assets/dist/js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="<?php echo base_url();?>assets/node_modules/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="<?php echo base_url();?>assets/node_modules/sparkline/jquery.sparkline.min.js"></script>
    <!--Custom JavaScript -->
    <script src="<?php echo base_url();?>assets/dist/js/custom.min.js"></script>
    <!--map-->
    <script src='https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=true'></script>

        <script src="<?php echo base_url();?>assets/js/index.js"></script>
    
<script type="text/javascript">
    function myFunction() {

    document.getElementById("fm").submit();
}
</script>
</body>
</html>